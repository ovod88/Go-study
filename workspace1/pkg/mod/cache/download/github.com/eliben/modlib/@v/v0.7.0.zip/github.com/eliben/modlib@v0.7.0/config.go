package modlib

func Config() string {
	return "modlib config"
}
