package clientlib

func Hello() string {
	return "clientlib hello"
}
