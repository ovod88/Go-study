package serverlib

func Hello() string {
	return "serverlib hello"
}
