package auth

func GetAuth() string {
	return "thou art authorized"
}
